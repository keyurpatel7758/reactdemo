﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApi.Entities;

namespace WebApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private List<Project> projectList = new List<Project>() {
            new Project{ Id = 1, Content = "Project 1 Content", Title= "Project 1"},
            new Project{ Id = 2, Content = "Project 2 Content", Title= "Project 2"}
        };

        [HttpGet]
        [Authorize(Roles = Role.Admin)]
        public IList<Project> GetAll() {
            return projectList;
        }
    }

    public class Project {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}