﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private List<Product> products = new List<Product> {
            new Product{ Name = "P1", Price="80" },
            new Product{ Name = "P2", Price= "50" }
        };

        
        //public IActionResult GetAll()
        //{ 
        //    return new response
        //}
    }

    public class Product
    {
        public string Name { get; set; }
        public string Price { get; set; }
    }
}